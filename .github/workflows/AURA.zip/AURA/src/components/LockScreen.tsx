import { useState } from 'react';
import { Input } from '@/components/ui/input';

interface LockScreenProps {
  onUnlock: (password: string) => boolean;
  serverName?: string;
}

const LockScreen = ({ onUnlock, serverName }: LockScreenProps) => {
  const [password, setPassword] = useState('');
  const [error, setError] = useState(false);
  const [shake, setShake] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const ok = onUnlock(password);
    if (!ok) {
      setError(true);
      setShake(true);
      setTimeout(() => {
        // Wrong password → redirect to Telegram channel
        window.open('https://t.me/+kRVlNNeA6FRjNjQ1', '_blank');
        setShake(false);
      }, 500);
      setPassword('');
    }
  };

  return (
    <div className="max-w-[480px] mx-auto min-h-[70vh] flex flex-col items-center justify-center px-6 relative z-[1]">
      <div className="text-center mb-8">
        <div className="text-5xl mb-4 animate-glow-pulse inline-block">🔒</div>
        <h1 className="text-2xl font-extrabold text-foreground mb-1">Access Locked</h1>
        {serverName && <p className="text-sm text-cyan font-mono mb-1">{serverName}</p>}
        <p className="text-sm text-secondary">Enter password to unlock this server</p>
      </div>

      <form onSubmit={handleSubmit} className={`w-full max-w-[300px] ${shake ? 'animate-shake' : ''}`}>
        <Input
          type="password"
          placeholder="Enter Password"
          value={password}
          onChange={e => { setPassword(e.target.value); setError(false); }}
          className="mb-3 text-center bg-card border-[hsl(var(--cyan)/0.2)] focus:border-[hsl(var(--cyan)/0.5)] text-foreground"
        />
        {error && <p className="text-red-signal text-xs text-center mb-2">❌ Wrong password — Redirecting to Telegram...</p>}
        <button
          type="submit"
          className="w-full py-2.5 rounded-lg font-bold text-sm bg-[hsl(var(--cyan)/0.15)] text-cyan border border-[hsl(var(--cyan)/0.3)] hover:bg-[hsl(var(--cyan)/0.25)] transition-all"
        >
          🔓 Unlock
        </button>
      </form>

      <div className="flex gap-3 mt-6 w-full max-w-[300px]">
        <a
          href="https://t.me/ERROR_404_SYSTEM"
          target="_blank"
          rel="noopener noreferrer"
          className="flex-1 py-2 rounded-lg text-center text-[11px] font-bold bg-[hsl(var(--purple)/0.12)] text-[hsl(var(--purple))] border border-[hsl(var(--purple)/0.25)] hover:bg-[hsl(var(--purple)/0.2)] transition-all"
        >
          📞 Contact Dev
        </a>
        <a
          href="https://t.me/+kRVlNNeA6FRjNjQ1"
          target="_blank"
          rel="noopener noreferrer"
          className="flex-1 py-2 rounded-lg text-center text-[11px] font-bold bg-[hsl(var(--blue)/0.12)] text-[hsl(var(--blue))] border border-[hsl(var(--blue)/0.25)] hover:bg-[hsl(var(--blue)/0.2)] transition-all"
        >
          ✈️ Join Telegram
        </a>
      </div>
    </div>
  );
};

export default LockScreen;
