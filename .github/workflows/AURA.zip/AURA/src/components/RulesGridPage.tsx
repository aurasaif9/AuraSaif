import { LogicEngine, TimeMode } from '@/lib/types';
import { LOGIC_NAMES, LOGIC_ICONS, MODE_CONFIGS } from '@/lib/api';

interface RulesGridPageProps {
  mode: TimeMode;
  engines: LogicEngine[];
  onBack: () => void;
  onSelectRule: (id: number) => void;
  time: string;
}

const rankBadgeClass = (idx: number) => {
  if (idx === 0) return 'bg-[hsl(var(--gold)/0.15)] text-gold border border-[hsl(var(--gold)/0.2)]';
  if (idx === 1) return 'bg-[rgba(192,192,192,0.1)] text-[#c0c0c0] border border-[rgba(192,192,192,0.15)]';
  if (idx === 2) return 'bg-[rgba(205,127,50,0.1)] text-[#cd7f32] border border-[rgba(205,127,50,0.15)]';
  return '';
};

const rankLabel = (idx: number) => {
  if (idx === 0) return '🏆 TOP·1ST';
  if (idx === 1) return '🥈 2ND';
  if (idx === 2) return '🥉 3RD';
  return '';
};

const iconGradients = [
  'gradient-purple', 'gradient-red', 'gradient-gold', 'gradient-cyan-blue', 'gradient-teal',
  'gradient-purple', 'gradient-red', 'gradient-gold', 'gradient-cyan-blue', 'gradient-teal',
  'gradient-purple', 'gradient-red', 'gradient-gold', 'gradient-cyan-blue', 'gradient-teal',
];

const RulesGridPage = ({ mode, engines, onBack, onSelectRule, time }: RulesGridPageProps) => {
  const cfg = MODE_CONFIGS[mode];
  
  // Sort by last 10 win rate
  const sorted = [...engines]
    .map((e, i) => {
      const last10 = e.history.slice(0, 10);
      const last10Wins = last10.filter(h => h.status === 'WIN').length;
      const last10Total = last10.length;
      const last10Rate = last10Total > 0 ? last10Wins / last10Total : 0;
      return { ...e, originalIndex: i, last10Rate, last10Wins, last10Total };
    })
    .sort((a, b) => b.last10Rate - a.last10Rate || b.last10Wins - a.last10Wins);

  const totalWins = engines.reduce((a, e) => a + e.wins, 0);
  const totalAll = engines.reduce((a, e) => a + e.wins + e.losses, 0);
  const overallRate = totalAll > 0 ? Math.round((totalWins / totalAll) * 100) : 0;

  return (
    <div className="animate-fade-up">
      <div className="flex items-center gap-3 px-1 pt-3.5 pb-2.5">
        <button onClick={onBack} className="w-9 h-9 rounded-[10px] border border-[hsl(0_0%_100%/0.06)] bg-card flex items-center justify-center cursor-pointer text-foreground text-base transition-all hover:border-glow">
          ←
        </button>
        <div className="flex-1">
          <div className="text-[17px] font-extrabold text-foreground">{cfg.label}</div>
          <div className="font-mono text-xs text-secondary">{time}</div>
        </div>
        <div className="text-right">
          <div className="text-[9px] text-tertiary uppercase tracking-wider">Win Rate</div>
          <div className="text-base font-extrabold font-mono text-foreground">{overallRate}%</div>
        </div>
      </div>

      <div className="flex items-center justify-between px-1 py-1.5 mb-2">
        <div className="flex items-center gap-1.5 text-[11px] font-semibold">
          <span className="w-[7px] h-[7px] rounded-full bg-[hsl(var(--green))] shadow-[0_0_8px_hsl(var(--green))] animate-pulse-dot" />
          <span className="text-cyan">CONNECTED</span>
        </div>
        <div className="text-[11px] text-secondary font-mono">{engines.length} active</div>
      </div>

      <div className="grid grid-cols-2 gap-2">
        {sorted.map((engine, sortedIdx) => {
          const wr = engine.last10Total > 0 ? Math.round(engine.last10Rate * 100) : 0;
          const idx = engine.originalIndex;
          
          return (
            <div
              key={engine.id}
              className="bg-card-glass rounded-[10px] p-3.5 cursor-pointer transition-all hover:border-glow hover:bg-card-hover-state flex items-center gap-2.5"
              onClick={() => onSelectRule(engine.id)}
            >
              <div className={`w-9 h-9 rounded-[10px] flex items-center justify-center text-lg flex-shrink-0 ${iconGradients[idx % iconGradients.length]}`}>
                {LOGIC_ICONS[idx]}
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-[13px] font-bold flex items-center gap-1 whitespace-nowrap overflow-hidden text-ellipsis text-foreground">
                  {LOGIC_NAMES[idx]}
                  {sortedIdx < 3 && (
                    <span className={`text-[8px] px-1.5 py-0.5 rounded font-bold whitespace-nowrap ${rankBadgeClass(sortedIdx)}`}>
                      {rankLabel(sortedIdx)}
                    </span>
                  )}
                </div>
                <div className="text-[10px] text-tertiary font-mono mt-0.5 flex items-center gap-1">
                  SERVER #{engine.id} · {wr}% WIN
                </div>
              </div>
              <div className="text-tertiary text-sm flex-shrink-0">›</div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default RulesGridPage;
