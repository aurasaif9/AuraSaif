import { useMemo } from 'react';
import { LogicEngine, TimeMode } from '@/lib/types';
import { LOGIC_NAMES, LOGIC_ICONS, MODE_CONFIGS } from '@/lib/api';

interface PredictionPageProps {
  mode: TimeMode;
  engine: LogicEngine;
  history: { period: string; number: number }[];
  onBack: () => void;
  time: string;
}

function formatPeriod(p: string) {
  if (!p) return '---';
  return p.length > 8 ? '...' + p.slice(-6) : p;
}

// Generate confidence once per engine render (stable via useMemo)
function generateConfidence(): number {
  const min = 50;
  const max = 90;
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

const PredictionPage = ({ mode, engine, history, onBack, time }: PredictionPageProps) => {
  const cfg = MODE_CONFIGS[mode];
  const idx = engine.id - 1;

  // Confidence calculated once per engine
  const confidence = useMemo(() => generateConfidence(), [engine.id, mode]);

  // Last 10 history items for accuracy
  const last10 = engine.history.slice(0, 10);
  const last10Wins = last10.filter(h => h.status === 'WIN').length;
  const last10Total = last10.length;
  const last10Accuracy = last10Total > 0 ? Math.round((last10Wins / last10Total) * 100) : 0;
  const last10Losses = last10Total - last10Wins;

  // Timer
  const sec = new Date().getSeconds();
  const remain = cfg.timerMod - (sec % cfg.timerMod);
  const circumference = 2 * Math.PI * 40;
  const offset = circumference - (remain / cfg.timerMod) * circumference;

  // Next period
  const nextPeriod = history.length > 0 ? (BigInt(history[0].period) + 1n).toString() : '---';

  const pred = engine.currentPrediction;

  return (
    <div className="animate-fade-up">
      {/* Top bar */}
      <div className="flex items-center gap-2.5 px-1 pt-3.5 pb-2.5">
        <button onClick={onBack} className="w-9 h-9 rounded-[10px] border border-[hsl(0_0%_100%/0.06)] bg-card flex items-center justify-center cursor-pointer text-foreground text-base transition-all hover:border-glow">
          ←
        </button>
        <div className="flex-1">
          <div className="text-base font-extrabold text-foreground">{LOGIC_NAMES[idx]}</div>
          <div className="text-[11px] text-secondary font-mono">SERVER #{engine.id} · {LOGIC_NAMES[idx]}</div>
        </div>
      </div>

      {/* Period + Timer */}
      <div className="bg-card-glass rounded-lg p-3.5 mb-2.5">
        <div className="flex items-center justify-between gap-2.5">
          <div className="flex-1">
            <div className="text-[0.65rem] tracking-[1.5px] uppercase text-secondary mb-0.5 font-medium">CURRENT PERIOD</div>
            <div className="digital-readout text-[1.8rem]">{formatPeriod(nextPeriod)}</div>
          </div>
          <div className="relative inline-flex items-center justify-center w-[70px] h-[70px] flex-shrink-0">
            <svg viewBox="0 0 100 100" className="w-[70px] h-[70px] -rotate-90">
              <circle className="stroke-[hsl(var(--cyan)/0.15)]" cx="50" cy="50" r="40" strokeWidth="4" fill="none" />
              <circle
                className="stroke-[hsl(var(--cyan))]"
                cx="50" cy="50" r="40" strokeWidth="4" fill="none"
                strokeLinecap="round"
                strokeDasharray={circumference}
                strokeDashoffset={offset}
                style={{ filter: 'drop-shadow(0 0 4px hsl(var(--cyan)))', transition: 'stroke-dashoffset 0.2s linear' }}
              />
            </svg>
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 font-mono text-[1.1rem] font-bold text-foreground" style={{ textShadow: '0 0 8px hsl(var(--cyan))' }}>
              {remain}s
            </div>
            <span className="absolute -right-2 top-1/2 -translate-y-1/2 w-2 h-2 bg-[hsl(var(--red))] rounded-full shadow-[0_0_10px_hsl(var(--red))] animate-pulse-dot" />
          </div>
        </div>
      </div>

      {/* Signal + Confidence combined */}
      <div className="bg-card-glass rounded-lg p-3.5 mb-2.5">
        <div className="flex justify-between items-center">
          <div>
            <div className="text-[0.65rem] tracking-[1.5px] uppercase text-secondary">SIGNAL</div>
            {pred ? (
              <div className={`inline-block px-5 py-2.5 rounded-[30px] font-bold text-2xl tracking-wider font-mono bg-[rgba(0,0,0,0.4)] backdrop-blur-sm border transition-all ${pred.type === 'Big' ? 'signal-big' : 'signal-small'}`}>
                {pred.type.toUpperCase()} {pred.calcNumber}
              </div>
            ) : (
              <div className="inline-block px-4 py-2 rounded-[30px] font-bold text-2xl tracking-wider font-mono bg-[rgba(0,0,0,0.4)] border border-[hsl(0_0%_100%/0.22)] text-[#b8c7dc]">
                WAIT
              </div>
            )}
          </div>
          <div className="text-right">
            <div className="text-[0.65rem] tracking-[1.5px] uppercase text-secondary">CONFIDENCE</div>
            <div className="font-mono text-lg font-bold text-green-signal">{pred ? `${confidence}%` : '--'}</div>
          </div>
        </div>
      </div>

      {/* Stats - Last 10 periods */}
      <div className="grid grid-cols-4 gap-1.5 mb-2.5">
        {[
          { label: 'ACCURACY', value: `${last10Accuracy}%` },
          { label: 'WINS', value: last10Wins },
          { label: 'LOSSES', value: last10Losses },
          { label: 'TOTAL', value: last10Total },
        ].map(s => (
          <div key={s.label} className="bg-[rgba(0,20,40,0.5)] rounded-[14px] p-2 backdrop-blur border border-[hsl(var(--cyan)/0.1)] flex flex-col gap-0.5 text-center">
            <span className="text-[0.55rem] uppercase text-secondary tracking-wider">{s.label}</span>
            <span className="font-mono text-lg font-semibold text-foreground">{s.value}</span>
          </div>
        ))}
      </div>

      {/* History table - Last 10 periods */}
      <div className="bg-card-glass rounded-lg overflow-hidden mb-2.5" style={{ padding: 0 }}>
        <div className="px-3 py-2 border-b border-[hsl(var(--cyan)/0.1)]">
          <span className="text-[0.65rem] text-secondary uppercase tracking-wider font-semibold">Last 10 Periods</span>
        </div>
        <div className="overflow-x-auto" style={{ WebkitOverflowScrolling: 'touch' }}>
          <table className="w-full border-collapse font-mono text-[0.75rem] min-w-[360px]">
            <thead>
              <tr className="bg-gradient-to-b from-[#0f1a2f] to-[#0b121f] border-b-[1.5px] border-b-[hsl(var(--cyan))]">
                <th className="py-2.5 px-1 text-left font-semibold text-cyan uppercase tracking-wider text-[0.65rem]">Period</th>
                <th className="py-2.5 px-1 text-left font-semibold text-cyan uppercase tracking-wider text-[0.65rem]">Number</th>
                <th className="py-2.5 px-1 text-left font-semibold text-cyan uppercase tracking-wider text-[0.65rem]">Prediction</th>
                <th className="py-2.5 px-1 text-left font-semibold text-cyan uppercase tracking-wider text-[0.65rem]">Result</th>
                <th className="py-2.5 px-1 text-left font-semibold text-cyan uppercase tracking-wider text-[0.65rem]">Status</th>
              </tr>
            </thead>
            <tbody>
              {/* Pending row */}
              {pred && (
                <tr>
                  <td className="py-2 px-1 border-b border-[hsl(var(--cyan)/0.08)]">{formatPeriod(nextPeriod)}</td>
                  <td className="py-2 px-1 border-b border-[hsl(var(--cyan)/0.08)]">-</td>
                  <td className="py-2 px-1 border-b border-[hsl(var(--cyan)/0.08)]">{pred.type} {pred.calcNumber}</td>
                  <td className="py-2 px-1 border-b border-[hsl(var(--cyan)/0.08)]">-</td>
                  <td className="py-2 px-1 border-b border-[hsl(var(--cyan)/0.08)]">
                    <span className="inline-block px-2 py-0.5 rounded-full font-semibold text-[0.65rem] text-center min-w-[50px] bg-[hsl(var(--gold)/0.1)] text-gold border border-[hsl(var(--gold))]">PENDING</span>
                  </td>
                </tr>
              )}
              {last10.map((item, i) => (
                <tr key={i}>
                  <td className="py-2 px-1 border-b border-[hsl(var(--cyan)/0.08)]">{formatPeriod(item.period)}</td>
                  <td className="py-2 px-1 border-b border-[hsl(var(--cyan)/0.08)]">{item.result}</td>
                  <td className="py-2 px-1 border-b border-[hsl(var(--cyan)/0.08)]">{item.prediction}</td>
                  <td className="py-2 px-1 border-b border-[hsl(var(--cyan)/0.08)]">{item.actual}</td>
                  <td className="py-2 px-1 border-b border-[hsl(var(--cyan)/0.08)]">
                    <span className={`inline-block px-2 py-0.5 rounded-full font-semibold text-[0.65rem] text-center min-w-[50px] ${item.status === 'WIN' ? 'bg-[hsl(var(--green)/0.2)] text-green-signal border border-[hsl(var(--green))]' : 'bg-[hsl(var(--red)/0.2)] text-red-signal border border-[hsl(var(--red))]'}`}>
                      {item.status}
                    </span>
                  </td>
                </tr>
              ))}
              {last10.length === 0 && !pred && (
                <tr><td colSpan={5} className="text-secondary text-center py-5">Waiting for data...</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      <div className="text-center text-[0.55rem] text-tertiary tracking-widest uppercase my-2">
        2026 V1 © VERSION -X HGNICE || DK HACK
      </div>
    </div>
  );
};

export default PredictionPage;
