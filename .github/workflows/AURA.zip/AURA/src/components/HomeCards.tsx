import { TimeMode } from '@/lib/types';

interface HomeCardsProps {
  wingoExpanded: boolean;
  setWingoExpanded: (v: boolean) => void;
  openGrid: (mode: TimeMode) => void;
  wingoIcon: string;
  k3Icon: string;
  trxIcon: string;
}

const modeSubCards = [
  { mode: '30s' as TimeMode, icon: '⚡', name: 'Wingo 30 Second', desc: 'Ultra fast prediction', badge: '30S' },
  { mode: '1m' as TimeMode, icon: '⏱️', name: 'Wingo 1 Min', desc: 'Standard speed', badge: '1M' },
  { mode: '3m' as TimeMode, icon: '⏳', name: 'Wingo 3 Min', desc: 'Balanced mode', badge: '3M' },
  { mode: '5m' as TimeMode, icon: '🕐', name: 'Wingo 5 Min', desc: 'High accuracy', badge: '5M' },
];

const HomeCards = ({ wingoExpanded, setWingoExpanded, openGrid, wingoIcon, k3Icon, trxIcon }: HomeCardsProps) => (
  <>
    {/* Wingo card - expandable */}
    <div className="bg-card-glass rounded-lg p-4 mb-3">
      <div
        className="flex items-center gap-3.5 cursor-pointer"
        onClick={() => setWingoExpanded(!wingoExpanded)}
      >
        <div className="w-[56px] h-[56px] rounded-[14px] bg-[hsl(var(--green)/0.1)] border border-[hsl(var(--green)/0.15)] flex items-center justify-center flex-shrink-0 relative overflow-hidden">
          <img src={wingoIcon} alt="Wingo" className="w-12 h-12 object-contain" />
          <span className="absolute -bottom-0.5 -right-0.5 w-[18px] h-[18px] rounded-full bg-[hsl(var(--green))] flex items-center justify-center text-[9px] text-background font-bold border-2 border-background">4</span>
        </div>
        <div className="flex-1">
          <div className="text-[15px] font-bold flex items-center gap-2 text-foreground">
            Wingo
            <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-[hsl(var(--green)/0.15)] text-green-signal tracking-wider uppercase">Active</span>
          </div>
          <div className="text-xs text-secondary mt-0.5">Color prediction · 4 modes</div>
          <div className="text-[11px] mt-1 flex items-center gap-1.5 text-green-signal">
            <span className="w-[5px] h-[5px] rounded-full bg-[hsl(var(--green))]" /> Live Now
          </div>
        </div>
        <div className="text-secondary text-lg transition-transform duration-200" style={{ transform: wingoExpanded ? 'rotate(180deg)' : 'rotate(0)' }}>
          ▾
        </div>
      </div>

      {wingoExpanded && (
        <div className="grid grid-cols-2 gap-2 mt-3.5 pt-3.5 border-t border-[hsl(0_0%_100%/0.06)]">
          {modeSubCards.map(card => (
            <div
              key={card.mode}
              className="bg-[hsl(var(--green)/0.04)] border border-[hsl(var(--green)/0.12)] rounded-lg p-3 cursor-pointer transition-all hover:bg-[hsl(var(--green)/0.08)] hover:border-[hsl(var(--green)/0.2)]"
              onClick={(e) => { e.stopPropagation(); openGrid(card.mode); }}
            >
              <div className="flex items-center justify-between mb-2">
                <div className="w-8 h-8 rounded-lg bg-[hsl(var(--green)/0.1)] flex items-center justify-center text-base">
                  {card.icon}
                </div>
                <span className="font-mono text-[10px] font-bold text-green-signal bg-[hsl(var(--green)/0.12)] px-1.5 py-0.5 rounded">
                  {card.badge}
                </span>
              </div>
              <div className="text-[12px] font-bold text-foreground">{card.name}</div>
              <div className="text-[10px] text-secondary mt-0.5">{card.desc}</div>
              <div className="text-[10px] mt-1.5 flex items-center gap-1 text-green-signal font-semibold">
                <span className="w-1 h-1 rounded-full bg-[hsl(var(--green))]" /> LIVE
              </div>
            </div>
          ))}
        </div>
      )}
    </div>

    {/* K3 - Coming Soon with glow */}
    <div className="bg-card-glass rounded-lg p-4 mb-3 flex items-center gap-3.5">
      <div className="w-[56px] h-[56px] rounded-[14px] bg-[hsl(var(--amber)/0.08)] border border-[hsl(var(--amber)/0.12)] flex items-center justify-center flex-shrink-0 overflow-hidden">
        <img src={k3Icon} alt="K3" className="w-12 h-12 object-contain" />
      </div>
      <div className="flex-1">
        <div className="text-[15px] font-bold flex items-center gap-2 text-foreground">K3</div>
        <div className="text-xs text-secondary mt-0.5">Dice prediction game</div>
        <div className="text-[11px] mt-1 font-semibold animate-text-glow">🔒 COMING SOON</div>
      </div>
      <div className="text-right flex-shrink-0">
        <div className="text-[9px] text-tertiary uppercase tracking-wider">Status</div>
        <div className="text-[13px] font-bold text-amber-signal font-mono">Dev</div>
      </div>
    </div>

    {/* TRX Wingo - Coming Soon with glow */}
    <div className="bg-card-glass rounded-lg p-4 mb-3 flex items-center gap-3.5">
      <div className="w-[56px] h-[56px] rounded-[14px] bg-[hsl(var(--purple)/0.08)] border border-[hsl(var(--purple)/0.12)] flex items-center justify-center flex-shrink-0 overflow-hidden">
        <img src={trxIcon} alt="TRX Wingo" className="w-12 h-12 object-contain" />
      </div>
      <div className="flex-1">
        <div className="text-[15px] font-bold flex items-center gap-2 text-foreground">TRX Wingo</div>
        <div className="text-xs text-secondary mt-0.5">Blockchain prediction game</div>
        <div className="text-[11px] mt-1 font-semibold animate-text-glow">🔒 COMING SOON</div>
      </div>
      <div className="text-right flex-shrink-0">
        <div className="text-[9px] text-tertiary uppercase tracking-wider">Status</div>
        <div className="text-[13px] font-bold text-amber-signal font-mono">Dev</div>
      </div>
    </div>

    {/* Pro Traders - Premium */}
    <div className="bg-gradient-to-br from-card to-secondary rounded-lg p-4 mb-3 border border-[hsl(var(--gold)/0.2)] relative overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,hsl(var(--gold)/0.08),transparent_60%)]" />
      <div className="relative">
        <div className="flex items-center gap-3 mb-2.5">
          <div className="w-14 h-14 rounded-xl gradient-gold flex items-center justify-center text-[26px] relative shadow-[0_0_20px_hsl(var(--gold)/0.3)]">
            👑
            <span className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-[hsl(var(--gold))] flex items-center justify-center text-[10px] border-2 border-background">⭐</span>
          </div>
          <div className="flex-1">
            <div className="text-[15px] font-bold flex items-center gap-1.5 text-foreground">
              Pro Traders
              <span className="text-[9px] bg-gradient-to-r from-[hsl(var(--gold)/0.3)] to-[hsl(var(--amber)/0.3)] text-gold px-2 py-0.5 rounded-full font-bold border border-[hsl(var(--gold)/0.4)] animate-glow-pulse">VIP</span>
            </div>
            <div className="text-xs text-secondary">Advanced AI signal · 17 Traders</div>
            <div className="text-[11px] text-green-signal flex items-center gap-1 mt-0.5">
              <span className="w-1.5 h-1.5 rounded-full bg-[hsl(var(--green))] animate-pulse-dot" /> Premium Access
            </div>
          </div>
          <div className="text-2xl text-gold ml-auto animate-glow-pulse">⚡</div>
        </div>
        <div className="flex items-center justify-between pt-2.5 border-t border-[hsl(0_0%_100%/0.08)]">
          <div className="flex gap-1">
            {['🐯', '🐉', '⭐', '🔥', '🐎'].map((e, i) => (
              <span key={i} className="w-6 h-6 rounded-full flex items-center justify-center text-[11px] border border-[hsl(var(--gold)/0.15)] bg-[hsl(var(--gold)/0.05)]">{e}</span>
            ))}
            <span className="text-xs text-secondary ml-1 self-center">+5 more</span>
          </div>
          <div className="font-mono text-[11px] text-gold bg-gradient-to-r from-[hsl(var(--gold)/0.12)] to-[hsl(var(--amber)/0.12)] border border-[hsl(var(--gold)/0.25)] px-3.5 py-1.5 rounded-full flex items-center gap-1 font-semibold cursor-pointer hover:bg-[hsl(var(--gold)/0.2)] transition-all shadow-[0_0_10px_hsl(var(--gold)/0.15)]">
            EXPLORE ›
          </div>
        </div>
      </div>
    </div>
  </>
);

export default HomeCards;
