interface StatusBarProps {
  isOnline: boolean;
  time: string;
}

const StatusBar = ({ isOnline, time }: StatusBarProps) => (
  <div className="flex items-center justify-between px-3.5 py-2 rounded-[10px] mb-3.5">
    <div className="flex items-center gap-1.5 text-xs font-semibold">
      <span className={`w-[7px] h-[7px] rounded-full animate-pulse-dot ${isOnline ? 'bg-[hsl(var(--green))] shadow-[0_0_8px_hsl(var(--green))]' : 'bg-[hsl(var(--red))] shadow-[0_0_8px_hsl(var(--red))]'}`} />
      <span className={isOnline ? 'text-green-signal' : 'text-red-signal'}>
        {isOnline ? 'ONLINE' : 'OFFLINE'}
      </span>
    </div>
    <div className="text-[11px] text-secondary font-mono">{time}</div>
  </div>
);

export default StatusBar;
