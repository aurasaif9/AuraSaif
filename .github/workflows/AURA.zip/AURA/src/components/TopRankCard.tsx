import { TimeMode } from '@/lib/types';
import { LOGIC_NAMES, LOGIC_ICONS } from '@/lib/api';

interface TopEngine {
  id: number;
  wins: number;
  losses: number;
  winRate: number;
  consecutiveWins: number;
  maxConsecutiveWins: number;
  history?: { status: string }[];
}

interface TopRankCardProps {
  mode: TimeMode;
  label: string;
  badge: string;
  topEngines: TopEngine[];
  hotStreakEngine: { id: number; consecutiveWins: number } | null;
  onClick: () => void;
}

const badgeColors: Record<string, string> = {
  '30S': 'bg-primary/10 text-cyan border-primary/20',
  '1M': 'bg-[hsl(var(--blue)/0.1)] text-[hsl(var(--blue))] border-[hsl(var(--blue)/0.2)]',
  '3M': 'bg-[hsl(var(--purple)/0.1)] text-[hsl(var(--purple))] border-[hsl(var(--purple)/0.2)]',
  '5M': 'bg-[hsl(var(--amber)/0.1)] text-amber-signal border-[hsl(var(--amber)/0.2)]',
};

const rankIcons = ['👑', '🥈', '🥉'];

const TopRankCard = ({ label, badge, topEngines, hotStreakEngine, onClick }: TopRankCardProps) => {
  // Find the engine with highest wins in last 10 for VIP badge
  const vipEngine = topEngines.length > 0 ? topEngines[0] : null;

  return (
    <div
      className="bg-card-glass rounded-lg p-4 mb-3 cursor-pointer transition-all hover:bg-card-hover-state hover:border-glow"
      onClick={onClick}
    >
      <div className="flex items-center justify-between mb-3.5">
        <div className="flex items-center gap-2">
          <span className="text-lg">🏆</span>
          <span className="text-sm font-bold text-foreground">{label}</span>
        </div>
        <span className={`font-mono text-[11px] px-2.5 py-1 rounded-md font-bold border ${badgeColors[badge] || badgeColors['30S']}`}>
          {badge}
        </span>
      </div>
      
      <div className="space-y-2">
        {topEngines.slice(0, 3).map((engine, idx) => {
          const last10 = (engine.history || []).slice(0, 10);
          const last10Wins = last10.filter(h => h.status === 'WIN').length;
          const last10Losses = last10.length - last10Wins;
          const last10Total = last10.length;
          const last10Rate = last10Total > 0 ? Math.round((last10Wins / last10Total) * 100) : 0;
          const isVip = vipEngine && engine.id === vipEngine.id;
          
          return (
            <div key={engine.id} className={`flex items-center gap-2.5 px-2.5 py-2 rounded-lg ${isVip ? 'bg-[hsl(var(--gold)/0.08)] border border-[hsl(var(--gold)/0.2)]' : 'bg-[hsl(0_0%_100%/0.02)]'}`}>
              <div className={`w-8 h-8 rounded-lg flex items-center justify-center text-sm ${idx === 0 ? 'bg-[hsl(var(--gold)/0.15)] border border-[hsl(var(--gold)/0.3)]' : idx === 1 ? 'bg-[rgba(192,192,192,0.1)] border border-[rgba(192,192,192,0.15)]' : 'bg-[rgba(205,127,50,0.1)] border border-[rgba(205,127,50,0.15)]'}`}>
                {rankIcons[idx]}
              </div>
              <span className="text-base">{LOGIC_ICONS[engine.id - 1]}</span>
              <div className="flex-1 min-w-0">
                <div className="text-[13px] font-bold text-foreground truncate flex items-center gap-1.5">
                  {LOGIC_NAMES[engine.id - 1]}
                  {isVip && (
                    <span className="text-[8px] font-bold px-1.5 py-0.5 rounded bg-[hsl(var(--gold)/0.2)] text-gold border border-[hsl(var(--gold)/0.3)] animate-glow-pulse">VIP</span>
                  )}
                </div>
                <div className="text-[10px] text-secondary font-mono flex items-center gap-1.5">
                  <span className="text-green-signal">{last10Wins}W</span>
                  <span>·</span>
                  <span className="text-red-signal">{last10Losses}L</span>
                  <span>·</span>
                  <span className="text-cyan">🔥 Max {engine.maxConsecutiveWins}</span>
                </div>
              </div>
              <span className="font-mono text-[15px] font-bold text-green-signal">
                {last10Rate}%
              </span>
            </div>
          );
        })}

        {/* MAX WIN STREAK */}
        {hotStreakEngine && hotStreakEngine.consecutiveWins > 0 && (
          <div className="flex items-center gap-2.5 px-2.5 py-2 rounded-lg bg-[hsl(var(--gold)/0.06)] border border-[hsl(var(--gold)/0.15)]">
            <div className="w-8 h-8 rounded-lg flex items-center justify-center text-sm bg-[hsl(var(--gold)/0.15)] border border-[hsl(var(--gold)/0.3)]">
              🔥
            </div>
            <span className="text-base">{LOGIC_ICONS[hotStreakEngine.id - 1]}</span>
            <div className="flex-1 min-w-0">
              <div className="text-[10px] font-bold text-gold uppercase tracking-wider">🔥 MAX WIN STREAK</div>
              <div className="text-[13px] font-bold text-foreground">{LOGIC_NAMES[hotStreakEngine.id - 1]}</div>
            </div>
            <span className="font-mono text-[13px] font-bold text-gold bg-[hsl(var(--gold)/0.12)] border border-[hsl(var(--gold)/0.25)] px-2.5 py-1 rounded-md">
              {hotStreakEngine.consecutiveWins} Wins
            </span>
          </div>
        )}

        {topEngines.length === 0 && (
          <div className="text-center text-xs text-secondary py-3 font-mono">Loading data...</div>
        )}
      </div>
    </div>
  );
};

export default TopRankCard;
