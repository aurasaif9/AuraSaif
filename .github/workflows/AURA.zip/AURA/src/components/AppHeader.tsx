import appLogo from '@/assets/app-logo.png';

const AppHeader = () => (
  <header className="flex items-center justify-between px-1 pt-4 pb-3">
    <div className="flex items-center gap-2.5">
      <div className="w-12 h-12 rounded-xl flex items-center justify-center relative">
        <img src={appLogo} alt="Lottery All Hack" className="w-12 h-12 object-contain" />
        <span className="absolute -top-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-[hsl(var(--green))] border-2 border-background shadow-[0_0_8px_hsl(var(--green))]" />
      </div>
      <div>
        <div className="text-[17px] font-extrabold tracking-tight text-foreground">Lottery All Hack</div>
        <div className="text-[11px] text-secondary font-mono tracking-widest uppercase">◎ Signal Dashboard</div>
      </div>
    </div>
    <div className="font-mono text-[11px] text-cyan border border-primary/30 px-3 py-1.5 rounded-full bg-primary/10 flex items-center gap-1.5 whitespace-nowrap">
      <span className="relative flex h-2.5 w-2.5">
        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[hsl(var(--cyan))] opacity-75"></span>
        <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-[hsl(var(--cyan))] shadow-[0_0_8px_hsl(var(--cyan))]"></span>
      </span>
      AI Powered
    </div>
  </header>
);

export default AppHeader;
