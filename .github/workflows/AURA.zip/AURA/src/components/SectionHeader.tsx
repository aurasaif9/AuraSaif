interface SectionHeaderProps {
  icon: string;
  title: string;
}

const SectionHeader = ({ icon, title }: SectionHeaderProps) => (
  <div className="flex items-center gap-2 my-4 px-0.5">
    <span className="text-xs font-bold tracking-[1.5px] uppercase text-secondary">
      {icon} {title}
    </span>
    <div className="flex-1 h-px bg-gradient-to-r from-[hsl(var(--cyan)/0.15)] to-transparent" />
  </div>
);

export default SectionHeader;
