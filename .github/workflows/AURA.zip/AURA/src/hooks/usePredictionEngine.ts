import { useState, useEffect, useCallback, useRef } from 'react';
import { HistoryRecord, LogicEngine, TimeMode, ModeState, ExtendedHistoryItem } from '@/lib/types';
import { fetchHistory, MODE_CONFIGS } from '@/lib/api';
import { runAllLogics, getResultType_ } from '@/lib/prediction-logic';

function createInitialEngines(): LogicEngine[] {
  return Array.from({ length: 17 }, (_, i) => ({
    id: i + 1,
    name: `Logic ${i + 1}`,
    wins: 0,
    losses: 0,
    currentPrediction: null,
    history: [],
    consecutiveWins: 0,
    maxConsecutiveWins: 0,
  }));
}

const STORAGE_PREFIX = 'lah_react_';

function saveModeState(mode: TimeMode, state: ModeState) {
  try {
    const data = {
      engines: state.engines.map(e => ({
        id: e.id, wins: e.wins, losses: e.losses,
        history: e.history.slice(0, 100),
        consecutiveWins: e.consecutiveWins,
        maxConsecutiveWins: e.maxConsecutiveWins,
      })),
      lastProcessedPeriod: state.lastProcessedPeriod,
      accumulatedHistory: state.accumulatedHistory.slice(0, 50),
    };
    localStorage.setItem(STORAGE_PREFIX + mode, JSON.stringify(data));
  } catch {}
}

function loadModeState(mode: TimeMode): ModeState {
  const state: ModeState = {
    engines: createInitialEngines(),
    history: [],
    lastProcessedPeriod: null,
    accumulatedHistory: [],
  };
  try {
    const raw = localStorage.getItem(STORAGE_PREFIX + mode);
    if (raw) {
      const d = JSON.parse(raw);
      if (d.engines) {
        d.engines.forEach((s: any) => {
          const e = state.engines.find(x => x.id === s.id);
          if (e) {
            e.wins = s.wins || 0;
            e.losses = s.losses || 0;
            e.history = s.history || [];
            e.consecutiveWins = s.consecutiveWins || 0;
            e.maxConsecutiveWins = s.maxConsecutiveWins || 0;
          }
        });
      }
      state.lastProcessedPeriod = d.lastProcessedPeriod || null;
      state.accumulatedHistory = d.accumulatedHistory || [];
    }
  } catch {}
  return state;
}

export function usePredictionEngine() {
  const [modeStates, setModeStates] = useState<Record<TimeMode, ModeState>>(() => ({
    '30s': loadModeState('30s'),
    '1m': loadModeState('1m'),
    '3m': loadModeState('3m'),
    '5m': loadModeState('5m'),
  }));
  const [isOnline, setIsOnline] = useState(false);
  const [currentTime, setCurrentTime] = useState(new Date());
  const statesRef = useRef(modeStates);
  statesRef.current = modeStates;

  const processMode = useCallback(async (mode: TimeMode) => {
    const results = await fetchHistory(mode);
    if (!results.length) return;

    setIsOnline(true);

    setModeStates(prev => {
      const ms = {
        ...prev[mode],
        engines: prev[mode].engines.map(e => ({ ...e })),
        history: [...results],
        accumulatedHistory: [...prev[mode].accumulatedHistory],
      };
      
      // Merge new results into accumulated history (newest first, keep up to 50)
      const existingPeriodSet = new Set(ms.accumulatedHistory.map(h => h.period));
      const newRecordsForAccum = results.filter(r => !existingPeriodSet.has(r.period));
      if (newRecordsForAccum.length > 0) {
        // Add new records and sort by period descending (newest first)
        ms.accumulatedHistory = [...newRecordsForAccum, ...ms.accumulatedHistory]
          .sort((a, b) => (BigInt(b.period) > BigInt(a.period) ? 1 : BigInt(b.period) < BigInt(a.period) ? -1 : 0))
          .slice(0, 50);
      }

      // Find new records to process for win/loss tracking
      const processedPeriods = new Set(
        ms.engines[0]?.history.map(h => h.period) || []
      );
      
      const newRecords = results.filter(r => !processedPeriods.has(r.period));
      
      if (newRecords.length > 0) {
        // Process in chronological order (oldest first)
        const toProcess = [...newRecords].reverse();
        
        for (const record of toProcess) {
          // Use accumulated history for predictions (records BEFORE this one)
          const historyBefore = ms.accumulatedHistory.filter(r => {
            return BigInt(r.period) < BigInt(record.period);
          });
          
          if (historyBefore.length < 3) continue;
          
          const nextPeriod = record.period;
          const predictions = runAllLogics(historyBefore, nextPeriod);
          const actualResult = getResultType_(record.number);
          
          ms.engines.forEach((engine, i) => {
            const pred = predictions[i];
            if (!pred) return;
            
            const status: 'WIN' | 'LOSS' = pred.type === actualResult ? 'WIN' : 'LOSS';
            
            const histItem: ExtendedHistoryItem = {
              period: record.period,
              prediction: pred.type,
              actual: actualResult,
              result: record.number,
              status,
            };
            
            engine.history = [histItem, ...engine.history].slice(0, 100);
            
            if (status === 'WIN') {
              engine.wins++;
              engine.consecutiveWins++;
              if (engine.consecutiveWins > engine.maxConsecutiveWins) {
                engine.maxConsecutiveWins = engine.consecutiveWins;
              }
            } else {
              engine.losses++;
              engine.consecutiveWins = 0;
            }
          });
          
          ms.lastProcessedPeriod = record.period;
        }
      }
      
      // Update current predictions using accumulated history
      if (ms.accumulatedHistory.length > 0) {
        const latestPeriod = ms.accumulatedHistory[0].period;
        const nextPeriod = (BigInt(latestPeriod) + 1n).toString();
        const predictions = runAllLogics(ms.accumulatedHistory, nextPeriod);
        ms.engines.forEach((engine, i) => {
          engine.currentPrediction = predictions[i];
        });
      }
      
      const newState = { ...prev, [mode]: ms };
      saveModeState(mode, ms);
      return newState;
    });
  }, []);

  // Initial fetch and polling
  useEffect(() => {
    const modes: TimeMode[] = ['30s', '1m', '3m', '5m'];
    modes.forEach(m => processMode(m));
    
    const interval = setInterval(() => {
      modes.forEach(m => processMode(m));
    }, 5000);
    
    return () => clearInterval(interval);
  }, [processMode]);

  // Clock
  useEffect(() => {
    const t = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  const getTopEngines = useCallback((mode: TimeMode, count = 5) => {
    const ms = modeStates[mode];
    return [...ms.engines]
      .map(e => {
        const last10 = e.history.slice(0, 10);
        const last10Wins = last10.filter(h => h.status === 'WIN').length;
        const last10Total = last10.length;
        const last10Rate = last10Total > 0 ? (last10Wins / last10Total) * 100 : 0;
        return { ...e, winRate: last10Rate };
      })
      .sort((a, b) => b.winRate - a.winRate || b.consecutiveWins - a.consecutiveWins)
      .slice(0, count);
  }, [modeStates]);

  const getHotStreakEngine = useCallback((mode: TimeMode) => {
    const ms = modeStates[mode];
    let best = ms.engines[0];
    ms.engines.forEach(e => {
      if (e.consecutiveWins > best.consecutiveWins) best = e;
    });
    return best.consecutiveWins > 0 ? best : null;
  }, [modeStates]);

  return {
    modeStates,
    isOnline,
    currentTime,
    processMode,
    getTopEngines,
    getHotStreakEngine,
  };
}
