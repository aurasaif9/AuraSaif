import { useState, useCallback } from 'react';

const PASSWORD = 'AURA X5';

export function useLock() {
  const [isUnlocked, setIsUnlocked] = useState(() => {
    return sessionStorage.getItem('lah_unlocked') === 'true';
  });

  const unlock = useCallback((password: string): boolean => {
    if (password === PASSWORD) {
      setIsUnlocked(true);
      sessionStorage.setItem('lah_unlocked', 'true');
      return true;
    }
    return false;
  }, []);

  const lock = useCallback(() => {
    setIsUnlocked(false);
    sessionStorage.removeItem('lah_unlocked');
  }, []);

  return { isUnlocked, unlock, lock };
}
