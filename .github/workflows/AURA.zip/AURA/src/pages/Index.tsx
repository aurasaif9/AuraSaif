import { useState } from 'react';
import { TimeMode } from '@/lib/types';
import { MODE_CONFIGS, LOGIC_NAMES } from '@/lib/api';
import { usePredictionEngine } from '@/hooks/usePredictionEngine';
import { useLock } from '@/hooks/useLock';
import AppHeader from '@/components/AppHeader';
import StatusBar from '@/components/StatusBar';
import SectionHeader from '@/components/SectionHeader';
import TopRankCard from '@/components/TopRankCard';
import RulesGridPage from '@/components/RulesGridPage';
import PredictionPage from '@/components/PredictionPage';
import LockScreen from '@/components/LockScreen';
import HomeCards from '@/components/HomeCards';

import wingoIcon from '@/assets/wingo-icon.png';
import k3Icon from '@/assets/k3-icon.png';
import trxIcon from '@/assets/trx-wingo-icon.png';

type Page = 'home' | 'grid' | 'prediction' | 'locked';

const Index = () => {
  const [page, setPage] = useState<Page>('home');
  const [selectedMode, setSelectedMode] = useState<TimeMode>('30s');
  const [selectedRuleId, setSelectedRuleId] = useState<number>(1);
  const [wingoExpanded, setWingoExpanded] = useState(false);
  const { modeStates, isOnline, currentTime, getTopEngines, getHotStreakEngine } = usePredictionEngine();
  const { isUnlocked, unlock } = useLock();

  const timeStr = currentTime.toLocaleTimeString();

  const openGrid = (mode: TimeMode) => {
    setSelectedMode(mode);
    setPage('grid');
  };

  const openPrediction = (ruleId: number) => {
    setSelectedRuleId(ruleId);
    if (!isUnlocked) {
      setPage('locked');
    } else {
      setPage('prediction');
    }
  };

  const handleUnlock = (password: string): boolean => {
    const ok = unlock(password);
    if (ok) {
      setPage('prediction');
    }
    return ok;
  };

  const modes: TimeMode[] = ['30s', '1m', '3m', '5m'];

  return (
    <div className="max-w-[480px] mx-auto relative z-[1] px-3 pb-5">
      {page === 'home' && (
        <div className="animate-fade-up">
          <AppHeader />
          <StatusBar isOnline={isOnline} time={timeStr} />

          <SectionHeader icon="✨" title="Prediction Games" />
          
          <HomeCards
            wingoExpanded={wingoExpanded}
            setWingoExpanded={setWingoExpanded}
            openGrid={openGrid}
            wingoIcon={wingoIcon}
            k3Icon={k3Icon}
            trxIcon={trxIcon}
          />

          <SectionHeader icon="🏆" title="Live Leaderboard" />

          {modes.map(mode => {
            const cfg = MODE_CONFIGS[mode];
            const top = getTopEngines(mode, 5);
            const hotStreak = getHotStreakEngine(mode);
            return (
              <TopRankCard
                key={mode}
                mode={mode}
                label={cfg.label}
                badge={cfg.badge}
                topEngines={top}
                hotStreakEngine={hotStreak}
                onClick={() => openGrid(mode)}
              />
            );
          })}

          <div className="text-center text-[0.55rem] text-tertiary tracking-widest uppercase mt-4 pb-2 animate-text-glow">
            2026 V1 © AURA -X  || DK HACK
          </div>
        </div>
      )}

      {page === 'grid' && (
        <RulesGridPage
          mode={selectedMode}
          engines={modeStates[selectedMode].engines}
          onBack={() => setPage('home')}
          onSelectRule={openPrediction}
          time={timeStr}
        />
      )}

      {page === 'locked' && (
        <div className="animate-fade-up">
          <div className="flex items-center gap-2.5 px-1 pt-3.5 pb-2.5">
            <button onClick={() => setPage('grid')} className="w-9 h-9 rounded-[10px] border border-[hsl(0_0%_100%/0.06)] bg-card flex items-center justify-center cursor-pointer text-foreground text-base transition-all hover:border-glow">
              ←
            </button>
            <div className="flex-1">
              <div className="text-base font-extrabold text-foreground">Server Access</div>
              <div className="text-[11px] text-secondary font-mono">SERVER #{selectedRuleId} · {LOGIC_NAMES[selectedRuleId - 1]}</div>
            </div>
          </div>
          <LockScreen
            onUnlock={handleUnlock}
            serverName={`SERVER #${selectedRuleId} · ${LOGIC_NAMES[selectedRuleId - 1]}`}
          />
        </div>
      )}

      {page === 'prediction' && (
        <PredictionPage
          mode={selectedMode}
          engine={modeStates[selectedMode].engines.find(e => e.id === selectedRuleId)!}
          history={modeStates[selectedMode].history}
          onBack={() => setPage('grid')}
          time={timeStr}
        />
      )}
    </div>
  );
};

export default Index;
