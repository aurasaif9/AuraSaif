import { HistoryRecord, TimeMode, ModeConfig } from './types';

export const MODE_CONFIGS: Record<TimeMode, ModeConfig> = {
  '30s': { apiPath: 'WinGo_30S', timerMod: 30, label: 'Wingo 30 Second', badge: '30S' },
  '1m': { apiPath: 'WinGo_1M', timerMod: 60, label: 'Wingo 1 Minute', badge: '1M' },
  '3m': { apiPath: 'WinGo_3M', timerMod: 180, label: 'Wingo 3 Minute', badge: '3M' },
  '5m': { apiPath: 'WinGo_5M', timerMod: 300, label: 'Wingo 5 Minute', badge: '5M' },
};

export async function fetchHistory(mode: TimeMode): Promise<HistoryRecord[]> {
  const cfg = MODE_CONFIGS[mode];
  try {
    const r = await fetch(`https://draw.ar-lottery01.com/WinGo/${cfg.apiPath}/GetHistoryIssuePage.json?t=${Date.now()}`);
    const j = await r.json();
    return (j?.data?.list || []).map((i: any) => ({
      period: String(i.issueNumber),
      number: parseInt(i.number),
    }));
  } catch {
    return [];
  }
}

export const LOGIC_NAMES = [
  'Tiger Pro', 'Dragon King', 'Phoenix VIP', 'Eagle Eye', 'Lion Heart',
  'Thunder Bolt', 'Shadow X', 'Cobra Strike', 'Wolf Pack', 'Blaze Pro',
  'Viper Gold', 'Rocket Star', 'Storm Chaser', 'Ninja Master', 'VIP Prediction',
  'Apex Titan', 'Dark Horse',
];

export const LOGIC_ICONS = [
  '🐯', '🐉', '🔥', '🦅', '🦁',
  '⚡', '🌀', '🐍', '🐺', '💥',
  '🐍', '🚀', '🌪️', '🥷', '👑',
  '⛰️', '🐎',
];
