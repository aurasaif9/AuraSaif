export interface HistoryRecord {
  period: string;
  number: number;
}

export interface PredictionResult {
  type: 'Big' | 'Small';
  calcNumber: number;
  logicName: string;
}

export interface ExtendedHistoryItem {
  period: string;
  prediction: string;
  actual: string;
  result: number;
  status: 'WIN' | 'LOSS';
}

export interface LogicEngine {
  id: number;
  name: string;
  wins: number;
  losses: number;
  currentPrediction: PredictionResult | null;
  history: ExtendedHistoryItem[];
  consecutiveWins: number;
  maxConsecutiveWins: number;
}

export type TimeMode = '30s' | '1m' | '3m' | '5m';

export interface ModeConfig {
  apiPath: string;
  timerMod: number;
  label: string;
  badge: string;
}

export interface ModeState {
  engines: LogicEngine[];
  history: HistoryRecord[];
  lastProcessedPeriod: string | null;
  accumulatedHistory: HistoryRecord[];
}
