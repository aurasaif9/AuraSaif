import { HistoryRecord, PredictionResult } from './types';

const BIG = 'Big' as const;
const SMALL = 'Small' as const;

function getResultType(n: number): 'Big' | 'Small' {
  return n >= 5 ? BIG : SMALL;
}

function digitSum(n: number): number {
  let num = Math.abs(n);
  while (num >= 10) {
    num = String(num).split('').reduce((a, b) => a + parseInt(b), 0);
  }
  return num;
}

function classify(n: number): 'Big' | 'Small' {
  const d = digitSum(Math.abs(n));
  return d >= 5 ? BIG : SMALL;
}

// Logic 1: A + B - C
function logic1(history: HistoryRecord[]): PredictionResult | null {
  if (history.length < 3) return null;
  const [a, b, c] = history.slice(0, 3).map(h => h.number);
  const result = a + b - c;
  const d = digitSum(Math.abs(result));
  return { type: d >= 5 ? BIG : SMALL, calcNumber: d, logicName: 'Logic 1' };
}

// Logic 2: A + B + C
function logic2(history: HistoryRecord[]): PredictionResult | null {
  if (history.length < 3) return null;
  const [a, b, c] = history.slice(0, 3).map(h => h.number);
  const result = a + b + c;
  const d = digitSum(result);
  return { type: d >= 5 ? BIG : SMALL, calcNumber: d, logicName: 'Logic 2' };
}

// Logic 3: Last 10 period count. Equal → sum all digits → digitSum
function logic3(history: HistoryRecord[]): PredictionResult | null {
  if (history.length < 10) return null;
  const last10 = history.slice(0, 10);
  let bigCount = 0, smallCount = 0;
  last10.forEach(h => {
    if (getResultType(h.number) === BIG) bigCount++;
    else smallCount++;
  });
  if (bigCount === smallCount) {
    const allSum = last10.reduce((a, h) => a + h.number, 0);
    const d = digitSum(allSum);
    return { type: d >= 5 ? BIG : SMALL, calcNumber: d, logicName: 'Logic 3' };
  }
  return { type: bigCount > smallCount ? BIG : SMALL, calcNumber: bigCount > smallCount ? bigCount : smallCount, logicName: 'Logic 3' };
}

// Logic 4: BIG sum - SMALL sum, digitSum
function logic4(history: HistoryRecord[]): PredictionResult | null {
  if (history.length < 10) return null;
  const last10 = history.slice(0, 10);
  let bigSum = 0, smallSum = 0;
  last10.forEach(h => {
    if (getResultType(h.number) === BIG) bigSum += h.number;
    else smallSum += h.number;
  });
  const diff = bigSum - smallSum;
  const d = digitSum(Math.abs(diff));
  return { type: d >= 5 ? BIG : SMALL, calcNumber: d, logicName: 'Logic 4' };
}

// Logic 5: BIG sum + SMALL sum, digitSum
function logic5(history: HistoryRecord[]): PredictionResult | null {
  if (history.length < 10) return null;
  const last10 = history.slice(0, 10);
  let bigSum = 0, smallSum = 0;
  last10.forEach(h => {
    if (getResultType(h.number) === BIG) bigSum += h.number;
    else smallSum += h.number;
  });
  const sum = bigSum + smallSum;
  const d = digitSum(sum);
  return { type: d >= 5 ? BIG : SMALL, calcNumber: d, logicName: 'Logic 5' };
}

// Logic 6: BIG sum - SMALL sum, digitSum
function logic6(history: HistoryRecord[]): PredictionResult | null {
  if (history.length < 10) return null;
  const last10 = history.slice(0, 10);
  let bigSum = 0, smallSum = 0;
  last10.forEach(h => {
    if (getResultType(h.number) === BIG) bigSum += h.number;
    else smallSum += h.number;
  });
  const diff = bigSum - smallSum;
  const d = digitSum(Math.abs(diff));
  return { type: d >= 5 ? BIG : SMALL, calcNumber: d, logicName: 'Logic 6' };
}

// Logic 7: Last 4 sum, digitSum
function logic7(history: HistoryRecord[]): PredictionResult | null {
  if (history.length < 4) return null;
  const sum = history.slice(0, 4).reduce((a, h) => a + h.number, 0);
  const d = digitSum(sum);
  return { type: d >= 5 ? BIG : SMALL, calcNumber: d, logicName: 'Logic 7' };
}

// Logic 8: Current period last 4 digits, multiply non-zero, digitSum, diff, last digit
function logic8(history: HistoryRecord[], currentPeriod: string): PredictionResult | null {
  const last4 = currentPeriod.slice(-4);
  const digits = last4.split('').map(Number);
  const nonZero = digits.filter(d => d !== 0);

  // 0000 → fallback to previous period
  if (nonZero.length === 0) {
    if (history.length === 0) return null;
    const prevResult = history[0].number;
    return { type: prevResult >= 5 ? BIG : SMALL, calcNumber: prevResult, logicName: 'Logic 8' };
  }

  // Single non-zero digit (e.g. 0001)
  if (nonZero.length === 1) {
    const val = nonZero[0];
    return { type: val >= 5 ? BIG : SMALL, calcNumber: val, logicName: 'Logic 8' };
  }

  const product = nonZero.reduce((a, b) => a * b, 1);
  const sumD = digitSum(product);
  const diff = Math.abs(product - sumD);
  const lastDigit = diff % 10;
  return { type: lastDigit >= 5 ? BIG : SMALL, calcNumber: lastDigit, logicName: 'Logic 8' };
}

// Logic 9: Same as 8 but final step is digitSum of diff
function logic9(history: HistoryRecord[], currentPeriod: string): PredictionResult | null {
  const last4 = currentPeriod.slice(-4);
  const digits = last4.split('').map(Number);
  const nonZero = digits.filter(d => d !== 0);

  if (nonZero.length === 0) {
    if (history.length === 0) return null;
    const prevResult = history[0].number;
    return { type: prevResult >= 5 ? BIG : SMALL, calcNumber: prevResult, logicName: 'Logic 9' };
  }

  if (nonZero.length === 1) {
    const val = nonZero[0];
    return { type: val >= 5 ? BIG : SMALL, calcNumber: val, logicName: 'Logic 9' };
  }

  const product = nonZero.reduce((a, b) => a * b, 1);
  const sumD = digitSum(product);
  const diff = Math.abs(product - sumD);
  const d = digitSum(diff);
  return { type: d >= 5 ? BIG : SMALL, calcNumber: d, logicName: 'Logic 9' };
}

// Logic 10: Logic1 - Logic2
function logic10(history: HistoryRecord[]): PredictionResult | null {
  const l1 = logic1(history);
  const l2 = logic2(history);
  if (!l1 || !l2) return null;
  const diff = Math.abs(l1.calcNumber - l2.calcNumber);
  const d = digitSum(diff);
  return { type: d >= 5 ? BIG : SMALL, calcNumber: d, logicName: 'Logic 10' };
}

// Logic 11: Logic1 + Logic2
function logic11(history: HistoryRecord[]): PredictionResult | null {
  const l1 = logic1(history);
  const l2 = logic2(history);
  if (!l1 || !l2) return null;
  const sum = l1.calcNumber + l2.calcNumber;
  const d = digitSum(sum);
  return { type: d >= 5 ? BIG : SMALL, calcNumber: d, logicName: 'Logic 11' };
}

// Logic 12: Logic1 - Logic2
function logic12(history: HistoryRecord[]): PredictionResult | null {
  const l1 = logic1(history);
  const l2 = logic2(history);
  if (!l1 || !l2) return null;
  const diff = Math.abs(l1.calcNumber - l2.calcNumber);
  const d = digitSum(diff);
  return { type: d >= 5 ? BIG : SMALL, calcNumber: d, logicName: 'Logic 12' };
}

// Logic 13: Logic5 + Logic6
function logic13(history: HistoryRecord[]): PredictionResult | null {
  const l5 = logic5(history);
  const l6 = logic6(history);
  if (!l5 || !l6) return null;
  const sum = l5.calcNumber + l6.calcNumber;
  const d = digitSum(sum);
  return { type: d >= 5 ? BIG : SMALL, calcNumber: d, logicName: 'Logic 13' };
}

// Logic 14: Logic5 - Logic6
function logic14(history: HistoryRecord[]): PredictionResult | null {
  const l5 = logic5(history);
  const l6 = logic6(history);
  if (!l5 || !l6) return null;
  const diff = Math.abs(l5.calcNumber - l6.calcNumber);
  const d = digitSum(diff);
  return { type: d >= 5 ? BIG : SMALL, calcNumber: d, logicName: 'Logic 14' };
}

// Logic 15: Majority vote of Logic 1-14
function logic15(history: HistoryRecord[], currentPeriod: string): PredictionResult | null {
  const logics = [
    logic1(history), logic2(history), logic3(history), logic4(history),
    logic5(history), logic6(history), logic7(history),
    logic8(history, currentPeriod), logic9(history, currentPeriod),
    logic10(history), logic11(history), logic12(history),
    logic13(history), logic14(history),
  ];
  let big = 0, small = 0;
  logics.forEach(l => { if (l) { if (l.type === BIG) big++; else small++; } });
  return { type: big >= small ? BIG : SMALL, calcNumber: big >= small ? big : small, logicName: 'VIP Prediction' };
}

// Logic 16: Smart Analysis
function logic16(history: HistoryRecord[]): PredictionResult | null {
  if (history.length < 5) return null;
  const last10 = history.slice(0, Math.min(10, history.length));
  const numbers = last10.map(h => h.number);
  const bigCount = numbers.filter(n => n >= 5).length;
  const smallCount = numbers.length - bigCount;

  let currentStreak = 1;
  const streakType = numbers[0] >= 5 ? BIG : SMALL;
  for (let i = 1; i < numbers.length; i++) {
    if ((numbers[i] >= 5 ? BIG : SMALL) === (numbers[i - 1] >= 5 ? BIG : SMALL)) {
      currentStreak++;
    } else break;
  }

  let prediction: 'Big' | 'Small';
  let calcNum: number;

  if (bigCount >= 7) { prediction = SMALL; calcNum = bigCount; }
  else if (smallCount >= 7) { prediction = BIG; calcNum = smallCount; }
  else if (currentStreak >= 3) { prediction = streakType === BIG ? SMALL : BIG; calcNum = currentStreak; }
  else { prediction = numbers[0] >= 5 ? SMALL : BIG; calcNum = numbers[0]; }

  return { type: prediction, calcNumber: calcNum, logicName: 'Logic 16' };
}

// Logic 17: Pattern System
function logic17(history: HistoryRecord[]): PredictionResult | null {
  if (history.length < 10) return null;
  const data = history.slice(0, Math.min(15, history.length)).map(h => h.number >= 5 ? 'big' : 'small');

  type PatternResult = { prediction: string; confidence: number };
  const matches: PatternResult[] = [];

  // Pattern 1: Repeating [A,B,C,A,B,C] → follow A
  if (data.length >= 6) {
    if (data[0] === data[3] && data[1] === data[4] && data[2] === data[5]) {
      matches.push({ prediction: data[0], confidence: 98 });
    }
  }

  // Pattern 2: Triple AAA → opposite
  if (data.length >= 3) {
    if (data[0] === data[1] && data[1] === data[2]) {
      const opposite = data[0] === 'big' ? 'small' : 'big';
      matches.push({ prediction: opposite, confidence: 97 });
    }
  }

  // Pattern 3: Weighted - Last 10 বেশি যেটা
  const last10 = data.slice(0, 10);
  const counts: Record<string, number> = {};
  last10.forEach(val => { counts[val] = (counts[val] || 0) + 1; });
  const maxCount = Math.max(...Object.values(counts));
  const best = Object.keys(counts).find(k => counts[k] === maxCount);
  if (best) matches.push({ prediction: best, confidence: 90 });

  // Pattern 4: Markov (min 15 data)
  if (data.length >= 15) {
    const transitions: Record<string, Record<string, number>> = {
      'big': { 'big': 0, 'small': 0 },
      'small': { 'big': 0, 'small': 0 }
    };
    for (let i = 1; i < data.length; i++) {
      transitions[data[i - 1]][data[i]]++;
    }
    const current = data[0];
    const total = transitions[current].big + transitions[current].small;
    if (total > 0) {
      const probBig = transitions[current].big / total;
      matches.push({ prediction: probBig > 0.5 ? 'big' : 'small', confidence: 97 });
    }
  }

  if (matches.length === 0) return null;

  const outcomeWeights: Record<string, number> = {};
  matches.forEach(m => {
    outcomeWeights[m.prediction] = (outcomeWeights[m.prediction] || 0) + m.confidence;
  });

  const maxWeight = Math.max(...Object.values(outcomeWeights));
  const bestPrediction = Object.keys(outcomeWeights).find(k => outcomeWeights[k] === maxWeight);

  const type = bestPrediction === 'big' ? BIG : SMALL;
  const calcNum = Math.round((maxWeight / Object.values(outcomeWeights).reduce((a, b) => a + b, 0)) * 9);

  return { type, calcNumber: calcNum, logicName: 'Logic 17' };
}

export function runAllLogics(history: HistoryRecord[], currentPeriod: string): (PredictionResult | null)[] {
  return [
    logic1(history), logic2(history), logic3(history), logic4(history),
    logic5(history), logic6(history), logic7(history),
    logic8(history, currentPeriod), logic9(history, currentPeriod),
    logic10(history), logic11(history), logic12(history),
    logic13(history), logic14(history),
    logic15(history, currentPeriod),
    logic16(history),
    logic17(history),
  ];
}

export function getResultType_(n: number): 'Big' | 'Small' {
  return getResultType(n);
}
